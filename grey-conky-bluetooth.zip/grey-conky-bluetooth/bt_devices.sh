#!/bin/bash
# Lists connected Bluetooth devices, one per line

devices=$(bluetoothctl devices 2>/dev/null)

if [ -z "$devices" ]; then
    echo "No devices found"
    exit 0
fi

found=0
while read -r line; do
    mac=$(echo "$line" | awk '{print $2}')
    name=$(echo "$line" | cut -d' ' -f3-)

    info=$(bluetoothctl info "$mac" 2>/dev/null)
    connected=$(echo "$info" | grep "Connected: yes")

    if [ -n "$connected" ]; then
        found=1
        battery=$(echo "$info" | grep "Battery Percentage" | awk -F'(' '{print $2}' | tr -d ')')
        clean_name=$(echo "$name" | tr -cd '[:print:]' | sed 's/[${}]//g')
        if [ -n "$battery" ]; then
            echo "${clean_name}: ${battery}%"
        else
            echo "${clean_name}"
        fi
    fi
done <<< "$devices"

if [ "$found" -eq 0 ]; then
    echo "No devices connected"
fi
