#!/bin/bash
##############################################
#                                            #
# Gather cdrom info                          #
#                                            #
# Scripted by Koentje  (remon@cobrasoft.nl)  #
#                                            #
#                               version 1.1  #
##############################################

device="/dev/sr0"




##########################################################################################################################
#######################################  AFTER THIS LINE CHANGE AT OWN RISK  #############################################
##########################################################################################################################

dev=$(basename $device)
vendor=$(cat /sys/class/block/$dev/device/vendor)
model=$(cat /sys/class/block/$dev/device/model)
echo "\${alignc}\${font Droid Sans:size=8}\${color1}Vendor: \${color0}$vendor"
echo "\${alignc}\${color1}Model: \${color0}$model"


# Disc loaded
media_count=$(udevadm info -q all -n "$device" | grep -c 'ID_CDROM_MEDIA')

if [ "$media_count" -eq 6 ]; then
    echo "\${alignc}\${color1}Status: \${color0}DVD loaded"
    echo "\${lua conky_image ./images/cd3.png 8 4 100 64}"
elif [ "$media_count" -eq 5 ]; then
    echo "\${alignc}\${color1}Status: \${color0}CD loaded"
    echo "\${lua conky_image ./images/cd2.png 14 4 94 72}"
else
    echo "\${alignc}\${color1}Status: \${color0}No disc"
    echo "\${lua conky_image ./images/cd.png 20 4 66 64}"
fi
    
# Check for label of disc
if [ "$(udevadm info -q all -n "$device" | grep 'ID_FS_LABEL')" != "" ]; then
    echo "\${alignc}\${color1}\${voffset -16}Label: \${color0}$(udevadm info -q all -n $device | grep 'ID_FS_LABEL=' | awk -F'=' '{print $2}')"
fi

# Check nr of tracks on music disc
if [ "$(udevadm info -q all -n "$device" | grep 'ID_CDROM_MEDIA_TRACK_COUNT_AUDIO')" != "" ]; then
   echo "\${alignc}\${color1}\${voffset -16}Tracks: \${color0}$(udevadm info -q all -n "$device" | grep 'ID_CDROM_MEDIA_TRACK_COUNT_AUDIO' | awk -F'=' '{print $2}')"
    # Execute album.sh and album2.sh
    ./album.sh
    ./album2.sh
fi


