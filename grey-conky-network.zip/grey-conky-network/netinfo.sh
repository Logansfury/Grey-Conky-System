#!/usr/bin/env bash
#
# netinfo.sh -- helper for the conky network widget.
#
#   netinfo.sh iface    wireless interface if present, else default-route one
#   netinfo.sh quality  signal % on Wi-Fi, link speed on Ethernet
#   netinfo.sh unit     the matching unit: "%" or "Mb"
#   netinfo.sh local    LAN IPv4 of that interface
#   netinfo.sh pubip    public IPv4, served from cache, never blocks
#
# WHY EACH OF THESE EXISTS
# ------------------------
# 1. ${wireless_link_qual_perc} only exists if conky was compiled with
#    wireless support, and many distro builds are not -- hence the
#    "unknown variable" error. 'quality' reads the same figure out of
#    /proc/net/wireless instead, so it works on any conky build.
#
# 2. On a wired machine there is no signal at all. 'quality' then reports
#    the Ethernet link speed, and 'unit' switches from % to Mb to match.
#
# 3. ${addr} and the IP-echo services both return whichever address family
#    the system offers first, which on a dual-stack box is usually IPv6 --
#    that is the long address you were seeing. Both are forced to IPv4 here.
#
# 4. conky runs ${execi} synchronously: the widget stops redrawing until
#    the command exits. 'pubip' therefore prints its cached value instantly
#    and forks a detached refresh only when that value has gone stale.

set -uo pipefail

CACHE_DIR="${XDG_RUNTIME_DIR:-/tmp}"
CACHE="$CACHE_DIR/conky-net-pubip"
IFACE_CACHE="$CACHE_DIR/conky-net-iface"
MAX_AGE=900          # seconds before the public IP is re-fetched
IFACE_MAX_AGE=60     # seconds before the interface is re-detected
CURL_TIMEOUT=8

# ---------------------------------------------------------------------
# Interface detection
# ---------------------------------------------------------------------
_detect_iface_raw() {
    local dev d

    # Preferred: iw lists only real 802.11 devices.
    if command -v iw >/dev/null 2>&1; then
        dev=$(iw dev 2>/dev/null | awk '$1=="Interface"{print $2; exit}')
        [[ -n ${dev:-} ]] && { printf '%s' "$dev"; return 0; }
    fi

    # sysfs marks wireless devices with a 'wireless' subdirectory.
    for d in /sys/class/net/*/wireless; do
        [[ -d $d ]] || continue
        dev=$(basename "$(dirname "$d")")
        printf '%s' "$dev"
        return 0
    done

    # No Wi-Fi at all (a wired desktop like the OptiPlex): fall back to
    # whatever owns the default route so the rest of the widget still works.
    dev=$(ip route show default 2>/dev/null | awk '{print $5; exit}')
    [[ -n ${dev:-} ]] && { printf '%s' "$dev"; return 0; }

    return 1
}

detect_iface() {
    # Cached, because several fields call this on every single update.
    if [[ -s $IFACE_CACHE ]]; then
        local age
        age=$(( $(date +%s) - $(stat -c %Y "$IFACE_CACHE" 2>/dev/null || echo 0) ))
        if (( age < IFACE_MAX_AGE )); then
            cat "$IFACE_CACHE"
            return 0
        fi
    fi

    local dev
    dev=$(_detect_iface_raw) || dev=""
    if [[ -n $dev ]]; then
        printf '%s' "$dev" > "$IFACE_CACHE.$$" && mv -f "$IFACE_CACHE.$$" "$IFACE_CACHE"
        printf '%s' "$dev"
    fi
}

is_wireless() {
    [[ -d "/sys/class/net/$1/wireless" ]]
}

# ---------------------------------------------------------------------
# Quality: signal % on Wi-Fi, link speed on Ethernet
# ---------------------------------------------------------------------
quality() {
    local dev
    dev=$(detect_iface)
    [[ -z $dev ]] && { printf -- '--'; return 0; }

    if ! is_wireless "$dev"; then
        # Wired: report negotiated link speed. Rendered in Gb once it
        # reaches 1000 Mb/s -- "1Gb" occupies the same two-character slot
        # the mockup's "96%" did, whereas "1000Mb" overruns the graph.
        local spd
        spd=$(cat "/sys/class/net/$dev/speed" 2>/dev/null)
        if [[ -n ${spd:-} && $spd =~ ^[0-9]+$ && $spd -gt 0 ]]; then
            if (( spd >= 1000 )); then
                # One decimal, trailing ".0" stripped: 1000->1, 2500->2.5
                awk -v s="$spd" 'BEGIN{v=s/1000; printf (v==int(v) ? "%d" : "%.1f"), v}'
            else
                printf '%d' "$spd"
            fi
        else
            printf -- '--'
        fi
        return 0
    fi

    # Wi-Fi, method 1: /proc/net/wireless 'link' column, a 0-70 quality
    # figure on virtually every driver. No conky wireless support needed.
    local link max=70
    if [[ -r /proc/net/wireless ]]; then
        link=$(awk -v d="$dev:" '$1==d {gsub(/\./,"",$3); print $3; exit}' /proc/net/wireless)
        if [[ -n ${link:-} && $link =~ ^-?[0-9]+$ ]]; then
            (( link < 0 )) && link=0
            (( link > max )) && link=$max
            printf '%d' $(( (link * 100 + max / 2) / max ))
            return 0
        fi
    fi

    # Wi-Fi, method 2: convert iw's dBm reading to a rough percentage,
    # treating -50 dBm as full scale and -100 dBm as zero.
    if command -v iw >/dev/null 2>&1; then
        local dbm p
        dbm=$(iw dev "$dev" link 2>/dev/null | awk '/signal:/{print int($2); exit}')
        if [[ -n ${dbm:-} && $dbm =~ ^-?[0-9]+$ ]]; then
            p=$(( 2 * (dbm + 100) ))
            (( p < 0 )) && p=0
            (( p > 100 )) && p=100
            printf '%d' "$p"
            return 0
        fi
    fi

    printf -- '--'
}

unit() {
    local dev spd
    dev=$(detect_iface)
    if [[ -z $dev ]]; then
        printf 'Mb'
    elif is_wireless "$dev"; then
        printf '%%'
    else
        # Must agree with quality(): Gb above 1000 Mb/s, Mb below.
        spd=$(cat "/sys/class/net/$dev/speed" 2>/dev/null)
        if [[ -n ${spd:-} && $spd =~ ^[0-9]+$ ]] && (( spd >= 1000 )); then
            printf 'Gb'
        else
            printf 'Mb'
        fi
    fi
}

# ---------------------------------------------------------------------
# Addresses -- IPv4 only, deliberately
# ---------------------------------------------------------------------
local_addr() {
    local dev a
    dev=$(detect_iface)
    [[ -z $dev ]] && { printf -- '--'; return 0; }
    a=$(ip -4 addr show "$dev" 2>/dev/null \
        | awk '/inet /{split($2,x,"/"); print x[1]; exit}')
    printf '%s' "${a:---}"
}

refresh_pubip() {
    local ip url
    # -4 is the fix: without it these endpoints answer over IPv6 whenever
    # IPv6 is available, which is where the long address came from.
    for url in https://ifconfig.me/ip https://api.ipify.org https://icanhazip.com; do
        ip=$(curl -4 -fsS --max-time "$CURL_TIMEOUT" "$url" 2>/dev/null | tr -d '[:space:]')
        if [[ -n $ip && $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            printf '%s' "$ip" > "$CACHE.$$" && mv -f "$CACHE.$$" "$CACHE"
            return 0
        fi
    done
    rm -f "$CACHE.$$"
    return 1
}

pubip() {
    if [[ ! -s $CACHE ]]; then
        setsid "$0" __refresh >/dev/null 2>&1 < /dev/null &
        printf '...'
        return 0
    fi

    local age
    age=$(( $(date +%s) - $(stat -c %Y "$CACHE" 2>/dev/null || echo 0) ))
    (( age > MAX_AGE )) && setsid "$0" __refresh >/dev/null 2>&1 < /dev/null &

    cat "$CACHE"
}

# ---------------------------------------------------------------------
case "${1:-}" in
    iface)      detect_iface ;;
    quality)    quality ;;
    unit)       unit ;;
    local)      local_addr ;;
    pubip)      pubip ;;
    __refresh)  refresh_pubip ;;   # internal: background fork target
    *)
        echo "usage: $(basename "$0") {iface|quality|unit|local|pubip}" >&2
        exit 2
        ;;
esac
