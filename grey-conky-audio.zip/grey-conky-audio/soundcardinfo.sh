#!/usr/bin/env bash
#
# soundcardinfo.sh -- helper for the conky "current audio device" widget.
#
#   soundcardinfo.sh probe     dump full pactl info for the default sink
#   soundcardinfo.sh card      make/model of whichever sink is DEFAULT right now
#   soundcardinfo.sh volume    master volume %, or "muted"
#   soundcardinfo.sh display   "<card name> -- <volume>%" / "-- muted"
#
# WHY "DEFAULT SINK" INSTEAD OF A HARDCODED DEVICE NAME
# -------------------------------------------------------
# headset.sh (the G930 widget) hardcodes one specific USB device on
# purpose -- it only ever cares about that one headset. This widget
# answers "what's my sound card right now", which could be the onboard
# Intel HDA chip, the AMD HDMI output, or the G930 base, depending on
# which one is currently the system default. So instead of matching a
# fixed device name, this reads whatever `pactl get-default-sink`
# currently reports and looks up that exact sink's properties, fresh,
# every call.
#
# The card-name lookup (alsa.card_name, falling back to
# device.vendor.name + device.product.name) is the same approach
# headset.sh already uses, already proven against real pactl output --
# see that script's comments for the reasoning on why alsa.card_name is
# preferred over the plain Description: field.

set -uo pipefail

# ---------------------------------------------------------------------
default_sink() {
    pactl get-default-sink 2>/dev/null
}

# card_name -- alsa.card_name (or vendor+product fallback) for whichever
# sink is currently default. Matches the *exact* sink's Name: line, not
# a substring pattern -- "whichever is active" is the whole point here,
# unlike headset.sh's fixed-device match.
card_name() {
    local sink
    sink=$(default_sink)
    [[ -z $sink ]] && return 1

    local target="Name: ${sink}"
    local field
    field=$(pactl list sinks 2>/dev/null | awk -v target="$target" -v key="alsa.card_name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0; sub(/^[ \t]+/, "", name) }
        {
            if (name == target && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')
    if [[ -n $field ]]; then
        printf '%s' "$field"
        return 0
    fi

    local vendor product
    vendor=$(pactl list sinks 2>/dev/null | awk -v target="$target" -v key="device.vendor.name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0; sub(/^[ \t]+/, "", name) }
        {
            if (name == target && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')
    product=$(pactl list sinks 2>/dev/null | awk -v target="$target" -v key="device.product.name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0; sub(/^[ \t]+/, "", name) }
        {
            if (name == target && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')

    vendor="${vendor%, Inc.}"
    vendor="${vendor%,}"

    if [[ -n $vendor && -n $product ]]; then
        printf '%s %s' "$vendor" "$product"
        return 0
    elif [[ -n $product ]]; then
        printf '%s' "$product"
        return 0
    fi

    return 1
}

# ---------------------------------------------------------------------
is_muted() {
    local sink out
    sink=$(default_sink)
    [[ -z $sink ]] && return 1
    out=$(pactl get-sink-mute "$sink" 2>/dev/null)
    [[ $out == *"yes"* ]]
}

# volume_pct -- first channel's % from `pactl get-sink-volume`. Enough
# for a single at-a-glance number even when channels are independently
# set, since that's rare outside deliberate balance tweaks.
volume_pct() {
    local sink out pct
    sink=$(default_sink)
    [[ -z $sink ]] && { printf -- '--'; return 0; }

    out=$(pactl get-sink-volume "$sink" 2>/dev/null)
    pct=$(grep -oE '[0-9]+%' <<< "$out" | head -n1 | tr -d '%')
    [[ -n $pct ]] && printf '%s' "$pct" || printf -- '--'
}

# ---------------------------------------------------------------------
probe() {
    local sink
    sink=$(default_sink)
    echo "== default sink =="
    echo "$sink"
    echo
    echo "== full sink info for the default =="
    pactl list sinks | grep -B2 -A40 "Name: ${sink}"
}

card() { card_name || printf -- '--'; }

volume() { volume_pct; }

# display -- exactly what conky.text should print: "<card name> --
# <volume>%", or "<card name> -- muted" when the default sink is muted.
# Plain text, no embedded conky color tags -- same reasoning as
# headset.sh: coloring (if wanted) should be handled from conky.text
# via ${if_match}, not from this script's stdout.
display() {
    local name vol
    name=$(card_name) || name="Unknown device"

    if is_muted; then
        printf '%s -- muted' "$name"
        return 0
    fi

    vol=$(volume_pct)
    printf '%s -- %s%%' "$name" "$vol"
}

# ---------------------------------------------------------------------
case "${1:-}" in
    probe)    probe ;;
    card)     card ;;
    volume)   volume ;;
    display)  display ;;
    *)
        echo "usage: $(basename "$0") {probe|card|volume|display}" >&2
        exit 2
        ;;
esac
