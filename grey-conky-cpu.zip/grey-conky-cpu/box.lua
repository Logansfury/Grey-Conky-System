-- Load Cairo functions (explicitly require the library)
require 'cairo'

-- Function to draw a rectangle with rounded corners
function draw_rounded_rectangle(cr, x, y, width, height, roundness, color, thickness)
    -- Set the color for the outline
    cairo_set_source_rgba(cr, color[1], color[2], color[3], color[4])

    -- Set the thickness of the outline
    cairo_set_line_width(cr, thickness)

    -- Calculate the radius of rounded corners based on the given percentage (roundness)
    local radius = math.min(width, height) * (roundness / 100)

    -- Draw the rounded rectangle
    cairo_new_sub_path(cr)
    cairo_arc(cr, x + width - radius, y + radius, radius, -math.pi / 2, 0)  -- Top-right corner
    cairo_arc(cr, x + width - radius, y + height - radius, radius, 0, math.pi / 2)  -- Bottom-right corner
    cairo_arc(cr, x + radius, y + height - radius, radius, math.pi / 2, math.pi)  -- Bottom-left corner
    cairo_arc(cr, x + radius, y + radius, radius, math.pi, 3 * math.pi / 2)  -- Top-left corner
    cairo_close_path(cr)

    -- Stroke the outline to actually draw it
    cairo_stroke(cr)
end

-- Main Conky function
function conky_main()
    if conky_window == nil then return end

    -- Create a Cairo drawing context
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)

    -- Set the color to white with full opacity
    local white = {1, 1, 1, 1}  -- (R, G, B, A)

    -- Set the roundness percentage here (e.g., 20 for 20% rounded corners)
    local roundness_percentage = 0

    -- Draw the rounded rectangle outline
    draw_rounded_rectangle(cr, 0, 0, 230, 1310, roundness_percentage, white, 1)

    -- Clean up
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end

