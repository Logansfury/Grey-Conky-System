--[[
    cpugraph.lua -- conky-cpu

    A single CPU load graph, drawn with Cairo. Ported from gpugraph.lua
    (conky-gpu): same plotting geometry, same grey-filled-area / white-
    top-line / transparent-behind look. The only real change is the data
    source -- there's no dump file to poll here, since conky can read
    CPU load itself. Each cycle this script just asks conky for
    ${cpu cpu0} directly via conky_parse().

    This replaces the native ${cpugraph 30,104 8a8a8a ffffff} call that
    used to sit at ${goto 108}${voffset -6} on the first line of
    conkyrc's conky.text. That native call is now removed from the text
    (the goto/voffset are left in place so nothing else in the layout
    shifts), and this script draws the same-sized graph in the same spot
    via lua_draw_hook_pre instead.

    CAUTION ON CFG.x / CFG.y BELOW: a lua_draw_hook_pre draws in
    absolute window pixel coordinates -- it has no idea where conky's
    text cursor would have been after ${goto 108}${voffset -6}. The
    values below are a best-effort estimate from the surrounding layout
    (72x72 icon at -p 10,2, temp text in a size-17 font, goto 108,
    voffset -6), not a measurement -- nudge them a few px once you see
    it rendered.

    USAGE (conky.config)
        lua_load = '~/.conky/grey-conky-cpu/cpugraph.lua',
        lua_draw_hook_pre = 'main',
        update_interval = 1.0,
--]]

pcall(require, "cairo")

-- Portable drawing-surface helper: prefer conky_surface() (X11 + Wayland),
-- fall back to cairo_xlib_surface_create for builds without it.
-- luacheck: ignore cairo_xlib
local has_cairo_xlib, cairo_xlib = pcall(require, "cairo_xlib")
if not has_cairo_xlib then
    cairo_xlib = setmetatable({}, {
        __index = function(_, k) return _G[k] end,
    })
end

local function get_draw_surface()
    if conky_surface then
        local s = conky_surface()
        if s then return s, false end
    end
    if conky_window and cairo_xlib_surface_create then
        local s = cairo_xlib_surface_create(conky_window.display,
            conky_window.drawable, conky_window.visual,
            conky_window.width, conky_window.height)
        return s, true
    end
    return nil, false
end

-- ==================== config ====================

local CFG = {
    -- Top-left corner of the graph inside the conky window.
    -- BEST-EFFORT ESTIMATE -- see the caution note at the top of this
    -- file. Matches the old ${goto 108}${voffset -6} spot: x=108 comes
    -- straight from the goto; y is guessed to vertically center the
    -- 30px-tall graph against the 72px icon (top at y=2) and the -6
    -- voffset. Nudge both until it lines up on your screen.
    x = 108,
    y = 0,

    -- Matches the old ${cpugraph 30,104 ...} call exactly: conky's
    -- graph syntax is HEIGHT,WIDTH, i.e. height=30 width=104.
    graph_width  = 104,
    graph_height = 54,

    -- Samples of history kept, one push per conky update. Native conky
    -- graphs scroll roughly one pixel per sample, so match that here:
    -- one history slot per pixel of width.
    graph_history_length = 104,

    -- GRAPH COLOURS
    -- Same 8a8a8a -> ffffff pairing the old ${cpugraph 30,104 8a8a8a
    -- ffffff} used, just split into a translucent fill + solid line
    -- the way gpugraph.lua does it instead of a flat two-colour blend.
    graph_grey_fill = 0x8a8a8a,
    graph_line      = 0xFFFFFF,
    fill_alpha      = 0.55,
    line_width      = 1.5,

    -- Red is kept at the very top of the AREA gradient so heavy load
    -- still reads hot. For a completely flat grey fill (closer to the
    -- original two-colour ${cpugraph}), set this to 0x8a8a8a as well.
    graph_peak      = 0xFF2021,
}

-- ==================== generic helpers ====================

-- Division-based hex->rgb (no bitwise ops, works on Lua 5.1 and 5.3+)
local function hex_to_rgb(hex)
    local r = math.floor(hex / 65536) % 256
    local g = math.floor(hex / 256) % 256
    local b = hex % 256
    return r / 255, g / 255, b / 255
end

local function hex_to_rgba(hex, alpha)
    local r, g, b = hex_to_rgb(hex)
    return r, g, b, alpha
end

-- locale-safe: treat "," as a decimal point rather than letting tonumber()
-- silently return nil on a comma-decimal locale.
local function num(s)
    if s == nil then return 0 end
    return tonumber((tostring(s):gsub(",", "."))) or 0
end

local function push_value(t, maxn, v)
    t[#t + 1] = v
    while #t > maxn do table.remove(t, 1) end
end

-- ==================== reading CPU load ====================

local cpu_hist = {}
local last_cpu = 0

-- Straight from conky itself -- no helper script or dump file needed,
-- since (unlike the GPU reading) conky already knows the CPU load
-- natively. cpu0 is the all-core average, matching what the rest of
-- this conkyrc's text (${cpu cpu0}) already displays.
local function read_cpu_load()
    local ok, raw = pcall(conky_parse, "${cpu cpu0}")
    if not ok or raw == nil then return last_cpu end

    local value = num(raw)
    if value < 0 then value = 0 end
    last_cpu = value
    return value
end

-- ==================== the graph ====================

-- Same construction as widget.lua's draw_mini_graph: clip, move the
-- origin to the bottom-left and flip Y so a larger value simply means a
-- larger Y, fill the area, then stroke the top edge.
local function draw_cpu_graph(cr, x, y, w, h, values, max)
    local n = #values
    if n < 1 then return end
    max = math.max(max, 1)
    local step = w / (CFG.graph_history_length - 1)

    cairo_save(cr)
    cairo_rectangle(cr, x, y, w, h)
    cairo_clip(cr)
    cairo_translate(cr, x, y + h)
    cairo_scale(cr, 1, -1)

    if n == 1 then
        -- Not enough history for a line yet -- a dot in the fill colour,
        -- so nothing shifts tone once the second sample arrives.
        local v0 = math.min(values[1], max)
        cairo_set_source_rgba(cr, hex_to_rgba(CFG.graph_grey_fill, 0.9))
        cairo_arc(cr, 0, (v0 / max) * h, 1.5, 0, 2 * math.pi)
        cairo_fill(cr)
        cairo_restore(cr)
        return
    end

    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)
    cairo_set_line_join(cr, CAIRO_LINE_JOIN_ROUND)

    -- 1. filled area -- grey at the bottom and middle, hot at the peak
    local fg_pat = cairo_pattern_create_linear(0, 0, 0, h)
    cairo_pattern_add_color_stop_rgba(fg_pat, 1.0, hex_to_rgba(CFG.graph_peak, 1.0))
    cairo_pattern_add_color_stop_rgba(fg_pat, 0.5, hex_to_rgba(CFG.graph_grey_fill, CFG.fill_alpha))
    cairo_pattern_add_color_stop_rgba(fg_pat, 0.0, hex_to_rgba(CFG.graph_grey_fill, CFG.fill_alpha))

    cairo_move_to(cr, 0, 0)
    for i = 1, n do
        local v = math.min(values[i], max)
        cairo_line_to(cr, (i - 1) * step, (v / max) * h)
    end
    cairo_line_to(cr, (n - 1) * step, 0)
    cairo_close_path(cr)

    cairo_set_source(cr, fg_pat)
    cairo_fill(cr)
    cairo_pattern_destroy(fg_pat)

    -- 2. top line -- flat white, no gradient
    local v0 = math.min(values[1], max)
    cairo_move_to(cr, 0, (v0 / max) * h)
    for i = 2, n do
        local v = math.min(values[i], max)
        cairo_line_to(cr, (i - 1) * step, (v / max) * h)
    end

    cairo_set_source_rgba(cr, hex_to_rgba(CFG.graph_line, 1.0))
    cairo_set_line_width(cr, CFG.line_width)
    cairo_stroke(cr)

    cairo_restore(cr)
end

-- ==================== Conky hook ====================

local function draw_all(cr)
    push_value(cpu_hist, CFG.graph_history_length, read_cpu_load())
    draw_cpu_graph(cr, CFG.x, CFG.y, CFG.graph_width, CFG.graph_height,
        cpu_hist, 100)
end

function conky_main()
    local surface, owns_surface = get_draw_surface()
    if not surface then return end
    local cr = cairo_create(surface)

    -- Clear ONLY the graph's own rectangle, never the whole surface.
    --
    -- cairo_paint() under CAIRO_OPERATOR_CLEAR wipes the entire window.
    -- That erases ${image} too -- and because conky caches images by
    -- default (rendering once rather than every cycle), nothing redraws
    -- it afterwards, so the icon vanishes. Text survived only because
    -- conky does redraw that each frame.
    --
    -- Clipping to the graph rect first keeps the clear local: successive
    -- frames still cannot stack, but everything conky drew elsewhere in
    -- the window is left alone.
    cairo_save(cr)
    cairo_rectangle(cr, CFG.x, CFG.y, CFG.graph_width, CFG.graph_height)
    cairo_clip(cr)
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR)
    cairo_paint(cr)
    cairo_set_operator(cr, CAIRO_OPERATOR_OVER)
    cairo_restore(cr)

    local ok, err = pcall(draw_all, cr)
    if not ok then
        io.stderr:write("cpugraph.lua draw error: " .. tostring(err) .. "\n")
    end

    cairo_destroy(cr)
    if owns_surface then
        cairo_surface_destroy(surface)
    end
end
