#!/usr/bin/env bash
#
# cpuinfo.sh -- CPU temperature and fan speed for the conky CPU widget.
#
#   cpuinfo.sh temp    CPU package temperature in whole degrees C
#   cpuinfo.sh fan     fan speed in RPM
#   cpuinfo.sh probe   show what was detected (run this once by hand)
#
# WHY THIS EXISTS
# ---------------
# conky's ${hwmon} needs a numeric index -- ${hwmon 2 temp 1} -- and that
# index is assigned by the kernel in probe order, so it changes between
# machines and can change across reboots. Hard-coding it is what makes
# most published conky CPU widgets show a blank or a wrong number on
# somebody else's box. This resolves the sysfs paths by NAME instead.
#
# Reads are plain sysfs, so there is no measurable cost; only the path
# discovery is cached.

set -uo pipefail

CACHE_DIR="${XDG_RUNTIME_DIR:-/tmp}"
PATH_CACHE="$CACHE_DIR/conky-cpu-paths"
CACHE_MAX_AGE=300

# Drivers that expose a real CPU die/package temperature, best first.
TEMP_DRIVERS="coretemp k10temp zenpower cpu_thermal acpitz"
# Drivers that expose a chassis/CPU fan, best first.
FAN_DRIVERS="dell_smm thinkpad nct6775 nct6779 nct6791 it87 asus applesmc"


# ------------------------------------------------------------------
# Resolve "<temp_path>|<fan_path>" and cache it.
# ------------------------------------------------------------------
_hwmon_name() {
    [[ -r "$1/name" ]] && cat "$1/name" 2>/dev/null || echo ""
}

_find_temp() {
    local want h n f lbl
    for want in $TEMP_DRIVERS; do
        for h in /sys/class/hwmon/hwmon*; do
            [[ -d $h ]] || continue
            n=$(_hwmon_name "$h")
            [[ $n == "$want" ]] || continue

            # Prefer the whole-package sensor over an individual core.
            for f in "$h"/temp*_label; do
                [[ -r $f ]] || continue
                lbl=$(cat "$f" 2>/dev/null)
                if [[ $lbl == *"Package"* || $lbl == *"Tdie"* || $lbl == *"Tctl"* ]]; then
                    echo "${f%_label}_input"
                    return 0
                fi
            done

            # No package label: fall back to the first reading.
            [[ -r "$h/temp1_input" ]] && { echo "$h/temp1_input"; return 0; }
        done
    done

    # Nothing recognised -- take any temperature at all.
    for h in /sys/class/hwmon/hwmon*/temp1_input; do
        [[ -r $h ]] && { echo "$h"; return 0; }
    done
    return 1
}

_find_fan() {
    local want h n f
    for want in $FAN_DRIVERS; do
        for h in /sys/class/hwmon/hwmon*; do
            [[ -d $h ]] || continue
            n=$(_hwmon_name "$h")
            [[ $n == "$want" ]] || continue
            for f in "$h"/fan*_input; do
                [[ -r $f ]] && { echo "$f"; return 0; }
            done
        done
    done

    # Any fan that is actually spinning beats a recognised one reading 0.
    for f in /sys/class/hwmon/hwmon*/fan*_input; do
        [[ -r $f ]] || continue
        [[ $(cat "$f" 2>/dev/null || echo 0) -gt 0 ]] && { echo "$f"; return 0; }
    done
    # Otherwise the first fan node that exists at all.
    for f in /sys/class/hwmon/hwmon*/fan*_input; do
        [[ -r $f ]] && { echo "$f"; return 0; }
    done
    return 1
}

resolve() {
    if [[ -s $PATH_CACHE ]]; then
        local age
        age=$(( $(date +%s) - $(stat -c %Y "$PATH_CACHE" 2>/dev/null || echo 0) ))
        if (( age < CACHE_MAX_AGE )); then
            cat "$PATH_CACHE"
            return 0
        fi
    fi

    local t f
    t=$(_find_temp) || t=""
    f=$(_find_fan)  || f=""
    printf '%s|%s' "$t" "$f" > "$PATH_CACHE.$$" && mv -f "$PATH_CACHE.$$" "$PATH_CACHE"
    printf '%s|%s' "$t" "$f"
}


# ------------------------------------------------------------------
temp() {
    local paths t raw
    paths=$(resolve); t=${paths%%|*}
    [[ -n $t && -r $t ]] || { printf -- '--'; return 0; }
    raw=$(cat "$t" 2>/dev/null)
    [[ $raw =~ ^-?[0-9]+$ ]] || { printf -- '--'; return 0; }
    # sysfs reports millidegrees; round rather than truncate.
    printf '%d' $(( (raw + 500) / 1000 ))
}

fan() {
    local paths f raw
    paths=$(resolve); f=${paths##*|}
    [[ -n $f && -r $f ]] || { printf -- '--'; return 0; }
    raw=$(cat "$f" 2>/dev/null)
    [[ $raw =~ ^[0-9]+$ ]] || { printf -- '--'; return 0; }
    printf '%d' "$raw"
}

probe() {
    local paths t f
    rm -f "$PATH_CACHE"
    paths=$(resolve); t=${paths%%|*}; f=${paths##*|}
    echo "temp sensor : ${t:-<none found>}"
    [[ -n $t ]] && echo "  driver    : $(cat "$(dirname "$t")/name" 2>/dev/null)"
    [[ -n $t ]] && echo "  reads     : $(temp) C"
    echo "fan sensor  : ${f:-<none found>}"
    [[ -n $f ]] && echo "  driver    : $(cat "$(dirname "$f")/name" 2>/dev/null)"
    [[ -n $f ]] && echo "  reads     : $(fan) rpm"
    echo
    echo "all hwmon devices on this machine:"
    for h in /sys/class/hwmon/hwmon*; do
        [[ -d $h ]] || continue
        printf '  %-22s %s\n' "$(basename "$h")" "$(_hwmon_name "$h")"
    done
}

case "${1:-}" in
    temp)  temp ;;
    fan)   fan ;;
    probe) probe ;;
    *)     echo "usage: $(basename "$0") {temp|fan|probe}" >&2; exit 2 ;;
esac
