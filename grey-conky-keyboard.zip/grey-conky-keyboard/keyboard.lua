--[[
    keyboard.lua
    Keyboard layout + Caps/Num lock indicator source for conky.

    Exposes four conky-callable globals:
        conky_kbd_update()  -- refreshes the cache; call ONCE, first thing
                               in conky.text, via ${lua kbd_update}
        conky_kbd_layout()  -- "us: layout" style string, coloured
        conky_kbd_caps()    -- "[caps lock]", red when active
        conky_kbd_num()     -- "[num lock]",  red when active

    The three getters read a cache that conky_kbd_update() fills, so a
    whole conky.text pass costs at most two forks (xset + layout probe)
    rather than one fork per indicator. Call them with ${lua_parse ...},
    NOT ${lua ...} -- conky does not re-parse ${color} escapes returned
    from a plain ${lua} call, so the colours would print as literal text.

    Requires: xset (x11-xserver-utils). Optional: xkblayout-state, which
    is the only reliable way to read the ACTIVE layout when more than one
    is configured -- see LAYOUT NOTES at the bottom of this file.
--]]

-- =====================================================================
--  CONFIG
-- =====================================================================
local CFG = {
    -- Colours as conky hex strings (no leading '#')
    COL_ACTIVE   = 'ff2d2d',  -- lock is ON  (red, as in the mockup)
    COL_INACTIVE = 'e8e8e8',  -- lock is OFF (near-white)
    COL_LAYOUT   = 'ff2d2d',  -- the layout code itself
    COL_LABEL    = 'e8e8e8',  -- the ": layout" label after it

    -- Text
    CAPS_TEXT = '[caps lock]',
    NUM_TEXT  = '[num lock]',
    LABEL     = ' layout',

    -- Re-probe the layout every N updates. Locks are read every update
    -- (they must feel instant); the layout almost never changes, so
    -- probing it constantly would just burn forks.
    LAYOUT_EVERY = 20,

    -- Shown when xset/X isn't reachable at all (e.g. pure Wayland)
    UNKNOWN = '??',
}

-- =====================================================================
--  STATE
-- =====================================================================
local cache = {
    caps   = false,
    num    = false,
    layout = CFG.UNKNOWN,
    ticks  = 0,
    ok     = false,   -- did the last xset probe succeed?
}

-- =====================================================================
--  PROBES
-- =====================================================================

-- Run a command, return stdout as a string (or nil on failure).
local function capture(cmd)
    local f = io.popen(cmd .. ' 2>/dev/null')
    if not f then return nil end
    local out = f:read('*a')
    f:close()
    if out == nil or out == '' then return nil end
    return out
end

-- `xset q` prints a line shaped like:
--   00: Caps Lock:   off    01: Num Lock:    on     02: Scroll Lock: off
-- Parsed by name rather than by LED-mask bit, because the mask's bit
-- assignment is not consistent across keyboard drivers.
local function read_locks()
    local out = capture('xset q')
    if not out then
        cache.ok = false
        return
    end
    cache.ok = true

    local caps = out:match('Caps%s+Lock:%s*(%a+)')
    local num  = out:match('Num%s+Lock:%s*(%a+)')

    cache.caps = (caps == 'on')
    cache.num  = (num  == 'on')
end

local function read_layout()
    -- Preferred: reports the layout group that is active RIGHT NOW.
    local out = capture('xkblayout-state print "%s"')
    if out then
        local code = out:match('^%s*([%w_-]+)')
        if code and code ~= '' then
            cache.layout = code
            return
        end
    end

    -- Fallback: setxkbmap lists every CONFIGURED layout, not the active
    -- one. With a single layout that's the same thing; with several
    -- ("us,de") we take the first and it will not follow group switches.
    out = capture('setxkbmap -query')
    if out then
        local list = out:match('layout:%s*([%w_,-]+)')
        if list then
            cache.layout = list:match('^([%w_-]+)') or list
            return
        end
    end

    cache.layout = CFG.UNKNOWN
end

-- =====================================================================
--  CONKY ENTRY POINTS
-- =====================================================================

function conky_kbd_update()
    read_locks()
    if cache.ticks % CFG.LAYOUT_EVERY == 0 then
        read_layout()
    end
    cache.ticks = cache.ticks + 1
    return ''   -- prints nothing
end

function conky_kbd_layout()
    return string.format('${color %s}%s${color %s}%s${color}',
        CFG.COL_LAYOUT, cache.layout, CFG.COL_LABEL, CFG.LABEL)
end

local function indicator(on, text)
    local col = on and CFG.COL_ACTIVE or CFG.COL_INACTIVE
    return string.format('${color %s}%s${color}', col, text)
end

function conky_kbd_caps()
    return indicator(cache.caps, CFG.CAPS_TEXT)
end

function conky_kbd_num()
    return indicator(cache.num, CFG.NUM_TEXT)
end

--[[
    LAYOUT NOTES
    ------------
    If you only ever use one keyboard layout, the setxkbmap fallback is
    fine and you need nothing extra.

    If you switch between layouts, install xkblayout-state -- setxkbmap
    reports what is configured, not what is selected, so without it the
    top line will sit on your first layout forever:

        git clone https://github.com/nonpop/xkblayout-state
        cd xkblayout-state && make && sudo cp xkblayout-state /usr/local/bin/

    Nothing here needs changing afterwards; read_layout() picks it up
    automatically and only falls through to setxkbmap if it's absent.
--]]
