#!/bin/bash
# fuzzy zeit v 1.1
# This script creates output lines for a fuzzy clock in ENGLISH
# designed to be displayed in conky
# Homepage:
# http://themuspilli.deviantart.com/art/Conky-Fuzzy-Zeit-1-0-542763343

export TZ='America/Los_Angeles'
minutes=`date +%M`
hour24=`date +%H`
hour12=`date +%I`

ref_hour=0
fuz_minutes=0
tod=0
is_am=0
is_pm=0
is_to=0
is_past=0

#####
# Fuzzy minutes - fuz_minutes
##############################

#  1  = FIVE (5,55)
#  2  = TEN (10,50)
#  3  = A QUARTER (15,45)
#  4  = TWENTY (20,40)
#  5  = TWENTYFIVE (25,35)
#  6  = HALF PAST 
#  7  = NEARLY
#  8  = SHARP
#  9  = SHORTLY PAST

# echo "m i n u t e s :" $minutes
case $minutes in
59|00|01)
  fuz_minutes=8
  ;;
02|03)
  fuz_minutes=9
  ;;
57|58)
  fuz_minutes=7
  ;;
04|05|06|07|08|54|55|56)
  fuz_minutes=1
  ;;
09|10|11|12|13|49|50|51|52|53)
  fuz_minutes=2
  ;;
14|15|16|17|18|44|45|46|47|48)
  fuz_minutes=3
  ;;
19|20|21|22|23|39|40|41|42|43)
  fuz_minutes=4
  ;;
24|25|26|27|34|35|36|37|38)
  fuz_minutes=5
  ;;
28|29|30|31|32|33)
  fuz_minutes=6
  ;;
*)
  fuz_minutes=0
  ;;
esac

####
# Hour referred to - ref_hour
##############################

if [ $minutes -le 33 ]; then # "to hour" starts in fuzzy mode with minute 34
	ref_hour=$hour12
	if [ $minutes -ge 4 ]; then # minutes 1-3 count as full hour or "shortly past"
		is_past=1
	fi
elif [ $minutes -ge 34 ]; then
	if [ $hour12 -eq 12 ]; then
		ref_hour=01
	else
		ref_hour=$(expr $hour12 + 1)
	fi
	if [ $minutes -lt 57 ]; then # "nearly x o'clock" does not want "to"
		is_to=1
	fi
fi

####
# Time of day or night - time_of_day (tod)
##########################################

# 1 = at night
# 2 = in the morning
# 3 = noon
# 4 = in the afternoon
# 5 = in the evening
# 6 = midnight
# is_am = am - if not in locale, 'date +%p' does not tell
# is_pm = pm - if not in locale, 'date +%p' does not tell
# 0 = not used

# shifting the range of an hour according to language 
# (10:55 = "5 to 11, thus the reference hour is 11, not 10)
if [ $minutes -ge 33 ] # in fuzzy mode but at xx:33 ends "half past"
then
  hour24=$(expr $hour24 + 1)
fi

tod=0
if [ $hour24 -ge 00 ]; then
  tod=2  # -> "in the morning" (common English says "3 in the morning",
         #    not "3 at night", for post-midnight/pre-dawn hours)
  is_am=1
  is_pm=0
fi
if [ $hour24 -ge 04 ]; then
  tod=2 # -> "in the morning"
fi
if [ $hour24 -ge 12 ]; then
  tod=4 # after 12 -> "in the afternoon"
fi
if  [ $hour24 -eq 12 ]; then
	if [ $minutes -ge 34 ]; then # actually 11:34+
		tod=2 # -> 10 minutes to 12 is still before noon, thus *in the morning*"
	fi
	# noon special, part 1
	if [ $minutes -le 1 ] || [ $minutes -ge 57 ]; then
		tod=3 # "nearly noon", "noon", "shortly past noon"
	fi
fi
if [ $hour24 -ge 13 ]; then
	is_am=0
	is_pm=1
fi
if [ $hour24 -ge 18 ]; then
	tod=5 # -> "in the evening"
fi
if [ $hour24 -eq 24 ]; then
	# the variable does not know it stores an hour; above we added 1 to 23 
	# and therefore we may encounter an hour 24 here
	tod=1 # -> "at night"
fi

# midnight special, part 1
if [ $hour24 -eq 00 ] || [ $hour24 -eq 24 ]; then 
	# we want "midnight, a quarter to mn, nearly mn, shortly past mn, a quarter past mn, half past mn"
	if [ $minutes -ge 57 ] || [ $minutes -le 03 ] || [ $fuz_minutes -eq 3 ] || [ $fuz_minutes -eq 6 ]; then
		tod=6 # -> "midnight"
	fi
fi

# taking back our little hour24 range correction
if [ $minutes -ge 33 ]
then
  hour24=$(expr $hour24 - 1)
fi

####
# And now for the single lines - zeile1-zeileb
# "zeile" is German for "line", avoiding to run
# into reserved keywords, variables or AMHDs
###############################################

## zeile 1: it is, nearly
if [ $fuz_minutes -eq 7 ]; then
	zeile1='n ${color1}I T ${color}n ${color1}I S ${color}a ${color1}N E A R L Y${color} m'
else
	zeile1='n ${color1}I T ${color}n ${color1}I S ${color}a N E A R L Y m'
fi

## zeile 2: minutes five, a (quarter), twenty, twentyfive, half
zeile2='T W E N T Y F I V E H A L F'
if [ $fuz_minutes -eq 1 ]; then
	zeile2='T W E N T Y ${color1}F I V E ${color}H A L F'
elif [ $fuz_minutes -eq 3 ]; then
	zeile2='T W E N T Y F I V E H ${color1}A ${color}L F'
elif [ $fuz_minutes -eq 4 ]; then
	zeile2='${color1}T W E N T Y ${color}F I V E H A L F'
elif [ $fuz_minutes -eq 5 ]; then
	zeile2='${color1}T W E N T Y F I V E ${color}H A L F'
elif [ $fuz_minutes -eq 6 ]; then
	zeile2='T W E N T Y F I V E ${color1}H A L F${color}'
fi

## zeile 3: minutes ten, (a) quarter, to
zeile3='Q U A R T E R e T E N i T O'
if [ $fuz_minutes -eq 2 ]; then # ten
	if [ $is_to -eq 1 ]; then # ten to
		zeile3='Q U A R T E R e ${color1}T E N ${color}i ${color1}T O${color}'
	else # ten (past)
		zeile3='Q U A R T E R e ${color1}T E N ${color}i T O'
	fi
elif [ $fuz_minutes -eq 3 ]; then # a quarter
	if [ $is_to -eq 1 ]; then
		zeile3='${color1}Q U A R T E R ${color}e T E N i ${color1}T O${color}'
	else
		zeile3='${color1}Q U A R T E R ${color}e T E N i T O'
	fi
else
	if [ $is_to -eq 1 ]; then # to, minutes 34 to 56
		zeile3='Q U A R T E R e T E N i ${color1}T O${color}'
	fi
fi

## zeile 4: shortly, past
zeile4='t S H O R T L Y g P A S T r'
if [ $fuz_minutes -eq 9 ]; then
		zeile4='t ${color1}S H O R T L Y ${color}g ${color1}P A S T ${color}r'
else
	if [ $is_past -eq 1 ]; then
		zeile4='t S H O R T L Y g ${color1}P A S T ${color}r'
	fi
fi

## zeile 5: hours one, two, four, five
zeile5='F I V E T W O N E F O U R e'
if [ $ref_hour -eq 1 ]; then
	zeile5='F I V E T W ${color1}O N E ${color}F O U R e'
elif [ $ref_hour -eq 2 ]; then
	zeile5='F I V E ${color1}T W O ${color}N E F O U R e'
elif [ $ref_hour -eq 4 ]; then
	zeile5='F I V E T W O N E ${color1}F O U R ${color}e'
elif [ $ref_hour -eq 5 ]; then
	zeile5='${color1}F I V E ${color}T W O N E F O U R e'
fi

## zeile 6: hours three, eight, twelve
zeile6='T W E L V E I G H T H R E E'
if [ $ref_hour -eq 3 ]; then
	zeile6='T W E L V E I G H ${color1}T H R E E${color}'
elif [ $ref_hour -eq 8 ]; then
	zeile6='T W E L V ${color1}E I G H T ${color}H R E E'
elif [ $ref_hour -eq 12 ] && [ $fuz_minutes -ne 8 ] ; then
	zeile6='${color1}T W E L V E ${color}I G H T H R E E'
fi

## zeile 7: hours seven, nine, eleven, in
zeile7='E L E V E N I N E S E V E N'
if [ $ref_hour -eq 7 ]; then
	zeile7='E L E V E N I N E ${color1}S E V E N${color}'
elif [ $ref_hour -eq 9 ]; then
	zeile7='E L E V E ${color1}N I N E ${color}S E V E N'
elif [ $ref_hour -eq 11 ]; then
	zeile7='${color1}E L E V E N ${color}I N E S E V E N'
## the first "in"
## we take the "in" inside "nine" for all hours possible, because
## it is nicer positioned than the next "in"
elif  [ $fuz_minutes -ne 7 ] && [ $fuz_minutes -ne 8 ] && [ $tod -ne 1 ]; then
	case $ref_hour in
	01|1|02|2|03|3|04|4|05|5|08|8|12)
		zeile7='E L E V E N ${color1}I N ${color}E S E V E N'
		;;
	*)
	    ;;
	esac
fi

## zeile 8: hours six, ten, o'clock
zeile8='T E N o S I X O '"'"' C L O C K'
if [ $fuz_minutes -eq 8 ] || [ $fuz_minutes -eq 7 ]; then  # full hour or "nearly" fh
	zeile8='T E N o S I X ${color1}O '"'"' C L O C K${color}'
	if [ $ref_hour -eq 6 ]; then # cheating here
		zeile8='T E N ${color1}S I X ${color}o ${color1}O '"'"' C L O C K${color}'
	elif [ $ref_hour -eq 10 ]; then
		zeile8='${color1}T E N ${color}o S I X ${color1}O '"'"' C L O C K${color}'
	fi
else # no full hour
	if [ $ref_hour -eq 6 ]; then
		zeile8='T E N o ${color1}S I X ${color}O '"'"' C L O C K'
	elif [ $ref_hour -eq 10 ]; then
		zeile8='${color1}T E N ${color}o S I X O '"'"' C L O C K'
	fi	
fi

## zeile 9: in, the, at, am, morning
zeile9='I N A T H E A M O R N I N G'
if [ $tod -eq 1 ]; then # at (night)
	zeile9='I N ${color1}A T ${color}H E A M O R N I N G'
else # not at night
	# in for "o clock" stuff
	case $ref_hour in 
	06|6|07|7|09|9|10|11)  ## the second "in" - for the rest (compare zeile7)
		if [ $tod -eq 2 ]; then # in the morning
			zeile9='${color1}I N ${color}A ${color1}T H E ${color}A ${color1}M O R N I N G${color}'
		elif [ $tod -eq 4 ] || [ $tod -eq 5 ] ; then  # in the (afternoon, evening)
			zeile9='${color1}I N ${color}A ${color1}T H E ${color}A M O R N I N G'
		fi
		;;
	*) 
		if [ $fuz_minutes -eq 7 ] || [ $fuz_minutes -eq 8 ]; then
			if [ $tod -eq 2 ]; then # in the morning
				zeile9='${color1}I N ${color}A ${color1}T H E ${color}A ${color1}M O R N I N G${color}'
			elif [ $tod -eq 4 ] || [ $tod -eq 5 ] ; then  # in the (afternoon, evening)
				zeile9='${color1}I N ${color}A ${color1}T H E ${color}A M O R N I N G'
			fi		
		else ## some who have already got an "in" in zeile7
			if [ $tod -eq 2 ]; then # (in) the morning
				zeile9='I N A ${color1}T H E ${color}A ${color1}M O R N I N G${color}'
			elif [ $tod -eq 4 ] || [ $tod -eq 5 ] ; then  # in the (afternoon, evening)
				zeile9='I N A ${color1}T H E ${color}A M O R N I N G'
			fi
		fi
		;;
	esac
fi

## zeile a: night afternoon
zeilea='M I D N I G H T A F T E R n'
if [ $tod -eq 1 ]; then
	zeilea='M I D ${color1}N I G H T ${color}A F T E R n'
elif [ $tod -eq 4 ]; then # after-noon; cheating in English, too ;-)
	zeilea='M I D N I G H T ${color1}A F T E R -${color}'
fi

## zeile b: evening, (after-) noon
zeileb='j E V E N I N G N O O N P M'
if [ $tod -eq 4 ]; then
	zeileb='j E V E N I N G ${color1}N O O N ${color}P M'
elif [ $tod -eq 5 ]; then
	zeileb='j ${color1}E V E N I N G ${color}N O O N P M'
fi

## noon special, part 2
if [ $tod -eq 3 ]; then
	zeile6='T W E L V E I G H T H R E E'
	zeile7='E L E V E N I N E S E V E N'
	zeile8='T E N o S I X O '"'"' C L O C K'
	zeile9='I N A T H E A M O R N I N G'
	zeilea='M I D N I G H T A F T E R n'
	zeileb='j E V E N I N G ${color1}N O O N ${color}P M'
fi

## midnight special, part 2
if [ $tod -eq 6 ]; then
	zeile6='T W E L V E I G H T H R E E'
	zeile7='E L E V E N I N E S E V E N'
	zeile8='T E N o S I X O '"'"' C L O C K'
	zeile9='I N A T H E A M O R N I N G'
	zeilea='${color1}M I D N I G H T ${color}A F T E R n'
	zeileb='j E V E N I N G N O O N P M'
fi

####
# And finally the output
#########################

## for debugging uncomment the following two lines:
# echo $hour24":"$minutes "h12" $hour12 "fm" $fuz_minutes "rh" $ref_hour
# echo "tod" $tod "i2" $is_to "ip" $is_past "am" $is_am "pm" $is_pm

echo $zeile1
echo $zeile2
echo $zeile3
echo $zeile4
echo $zeile5
echo $zeile6
echo $zeile7
echo $zeile8
echo $zeile9
echo $zeilea
echo $zeileb

exit 0
