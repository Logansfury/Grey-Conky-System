#!/usr/bin/env bash
#
# headsetinfo.sh -- helper for a conky headset/mic-jack widget.
#
#   headsetinfo.sh probe        dump all sink/source ports, for finding names
#   headsetinfo.sh headphones   analog jack: "plugged" / "unplugged" / "--"
#   headsetinfo.sh mic          analog jack: "plugged" / "unplugged" / "--"  (see note)
#   headsetinfo.sh usb_status   USB headset base: "plugged" / "unplugged"
#   headsetinfo.sh usb_model    USB headset make/model, or "--" if unplugged
#   headsetinfo.sh display      one-line status for conky:
#                                "no headphones connected", or "make: model"
#
# WHY THIS EXISTS
# ----------------
# conky has no native jack-detect variable. The codec itself supports
# unsolicited jack-sense events (confirmed via
# /proc/asound/card*/codec#* -- "Unsolicited: tag=01, enabled=1" on the
# front HP pin), but that's raw HDA codec state, not something conky or
# a shell script should poll directly. PulseAudio/PipeWire already
# turns those events into a per-port "available" / "not available"
# flag, which is what this script reads instead.
#
# TWO DIFFERENT KINDS OF "PLUGGED IN" HERE
# -----------------------------------------
# headphones/mic (above) watch the onboard analog jacks via port
# availability, as before.
#
# usb_status/usb_model are for a *wireless* headset (a Logitech G930 in
# this case) that connects to its own base station over 2.4GHz, with
# the base station itself plugged into the PC over USB. That distinction
# matters: unplugging the headset's own charging cable from the headset
# does NOT disconnect the base from the PC, so it's invisible to
# PulseAudio. Only unplugging the base station's USB cable from the PC
# makes its ALSA sink/source appear or disappear, which is what
# usb_status actually detects.
#
# PORT/DEVICE NAMES ARE HARDCODED, not auto-detected -- same tradeoff
# netgraph.lua made with its interface name. Run 'probe' once, confirm
# the names below still match, and edit CFG_* if they don't.

set -uo pipefail

# ---------------------------------------------------------------------
# Port names -- confirmed via `pactl list sinks`/`sources` on this
# machine:
#     analog-output-headphones: Headphones (..., not available)
#     analog-input-mic: Microphone (..., availability unknown)
# Re-run `headsetinfo.sh probe` after any audio hardware/driver change.
#
# NOTE ON THE MIC PORT: "availability unknown" (not "available" /
# "not available") means this codec has no jack-sense wired to the mic
# pin -- confirmed by the earlier /proc/asound/card*/codec#* dump,
# which showed an "Unsolicited" sense event on the HP pin but no
# corresponding Mic pin entry at all. PulseAudio genuinely can't tell
# whether a mic is plugged in here; mic() below will correctly fall
# through to "--" rather than guess.
CFG_HEADPHONE_PORT="analog-output-headphones"
CFG_MIC_PORT="analog-input-mic"

# USB headset base station -- matched against the sink/source Name:
# field, e.g. "alsa_output.usb-Logitech_Logitech_G930_Headset-00...".
# A substring is enough; it doesn't need the trailing .analog-stereo.
CFG_USB_HEADSET_MATCH="Logitech_G930"

# ---------------------------------------------------------------------
probe() {
    echo "== sinks (outputs) =="
    pactl list sinks | grep -B4 "Ports:" | grep -E "Sink #|Name:|Ports:"
    echo
    echo "== sink ports =="
    pactl list sinks | grep -A4 "Ports:"
    echo
    echo "== sources (inputs) =="
    pactl list sources | grep -B4 "Ports:" | grep -E "Source #|Name:|Ports:"
    echo
    echo "== source ports =="
    pactl list sources | grep -A4 "Ports:"
}

# port_status <port_name> -- "plugged" / "unplugged" / "--"
#
# Matches the exact "<port_name>: ..." line, then checks for the
# trailing "(...not available)" vs "(...available)" tag pactl prints.
# Checked in this order because "not available" contains "available"
# as a substring.
port_status() {
    local port="$1" line
    [[ -z $port ]] && { printf -- '--'; return 0; }

    line=$(pactl list sinks 2>/dev/null; pactl list sources 2>/dev/null) \
        || { printf -- '--'; return 0; }
    line=$(grep -F "${port}:" <<< "$line" | head -n1)

    if [[ -z $line ]]; then
        printf -- '--'
    elif [[ $line == *"not available"* ]]; then
        printf 'unplugged'
    elif [[ $line == *"available"* ]]; then
        printf 'plugged'
    else
        printf -- '--'
    fi
}

headphones() { port_status "$CFG_HEADPHONE_PORT"; }
mic()        { port_status "$CFG_MIC_PORT"; }

# ---------------------------------------------------------------------
# USB headset base station -- whole-device presence, not a port flag.
# The sink for it only exists in `pactl list sinks` at all while the
# base's USB cable is plugged into the PC, so "does a matching Name:
# line exist" IS the plug state -- no available/unavailable tag needed.
# ---------------------------------------------------------------------

usb_status() {
    if pactl list short sinks 2>/dev/null | grep -qF "$CFG_USB_HEADSET_MATCH"; then
        printf 'plugged'
    else
        printf 'unplugged'
    fi
}

# usb_description -- prefers pactl's alsa.card_name property, which on
# this device is a clean "Logitech G930 Headset" with no cleanup
# needed. The plain Description: field turned out to just be "G930
# Analog Stereo" -- no vendor name at all -- so it's not used here.
# Falls back to device.vendor.name + device.product.name (stripping
# vendor's ", Inc." suffix) for devices that lack alsa.card_name.
# Prints nothing (not "--") when unplugged, so callers can tell "found
# but empty" apart from "not found".
usb_description() {
    local field
    field=$(pactl list sinks 2>/dev/null | awk -v pat="$CFG_USB_HEADSET_MATCH" -v key="alsa.card_name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0 }
        {
            if (name ~ pat && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')
    if [[ -n $field ]]; then
        printf '%s' "$field"
        return 0
    fi

    local vendor product
    vendor=$(pactl list sinks 2>/dev/null | awk -v pat="$CFG_USB_HEADSET_MATCH" -v key="device.vendor.name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0 }
        {
            if (name ~ pat && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')
    product=$(pactl list sinks 2>/dev/null | awk -v pat="$CFG_USB_HEADSET_MATCH" -v key="device.product.name" '
        /^Sink #/ { name="" }
        /Name: / { name=$0 }
        {
            if (name ~ pat && index($0, key " = \"") > 0) {
                match($0, /"[^"]*"/)
                print substr($0, RSTART + 1, RLENGTH - 2)
                exit
            }
        }
    ')

    vendor="${vendor%, Inc.}"
    vendor="${vendor%,}"

    if [[ -n $vendor && -n $product ]]; then
        printf '%s %s' "$vendor" "$product"
        return 0
    elif [[ -n $product ]]; then
        printf '%s' "$product"
        return 0
    fi

    return 1
}

# usb_model -- full cleaned description, or "--" if unplugged.
usb_model() {
    local desc
    if desc=$(usb_description); then
        printf '%s' "$desc"
    else
        printf -- '--'
    fi
}

# display -- exactly what conky.text should print: either
# "no headphones connected" in the default text color, or
# "Make: Model" in red (FF0000) while the base is plugged in. First
# word of the cleaned description is treated as the make, everything
# after it as the model.
#
# The ${color ...} / ${color} tags below are conky markup, not shell --
# they rely on this being called via ${execpi ...} rather than
# ${exec ...}: the trailing "p" in execpi tells conky to parse its
# output for conky syntax (colors, etc.) instead of printing it as
# literal text. conkyrc in this widget already uses execpi, so this
# works as-is.
display() {
    local desc make model
    if ! desc=$(usb_description); then
        printf 'no headphones connected'
        return 0
    fi

    read -r make model <<< "$desc"
    if [[ -z $model ]]; then
        printf '${color FF0000}%s${color}' "$make"
    else
        printf '${color FF0000}%s: %s${color}' "$make" "$model"
    fi
}

# ---------------------------------------------------------------------
case "${1:-}" in
    probe)       probe ;;
    headphones)  headphones ;;
    mic)         mic ;;
    usb_status)  usb_status ;;
    usb_model)   usb_model ;;
    display)     display ;;
    *)
        echo "usage: $(basename "$0") {probe|headphones|mic|usb_status|usb_model|display}" >&2
        exit 2
        ;;
esac
