#!/bin/bash

# Run hwinfo --mouse and store output in a variable
mouse_info=$(hwinfo --mouse)

# Extract the last mouse block using awk
last_mouse_block=$(echo "$mouse_info" | awk '
    BEGIN { RS=""; FS="\n" } 
    /USB Mouse/ { last_block = $0 } 
    END { print last_block }')

# Extract specific details from the last mouse block
vendor=$(echo "$last_mouse_block" | awk -F'"' '/Vendor:/ { print $2 }')
device=$(echo "$last_mouse_block" | awk -F'"' '/Device:/ { print $2 }')
speed=$(echo "$last_mouse_block" | awk '/Speed:/ { print $2 " " $3 }')
buttons=$(echo "$last_mouse_block" | awk '/Buttons:/ { print $2 }')
wheels=$(echo "$last_mouse_block" | awk '/Wheels:/ { print $2 }')

# Write the extracted values to mouse.txt
{
    echo "\${alignc}\${color0}Vendor: \${color1}$vendor"
    echo "\${alignc}\${color0}Device: \${color1}$device"
    echo "\${alignc}\${color0}Speed: \${color1}$speed"
    echo "\${alignc}\${color0}Buttons: \${color1}$buttons \${alignc 12}\${color0}Wheels: \${color1}$wheels"
} > mouse.txt

