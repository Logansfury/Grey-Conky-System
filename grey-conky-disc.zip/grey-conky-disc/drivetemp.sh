#!/usr/bin/env bash
#
# drivetemp.sh -- helper for a conky drive-temperature widget.
#
#   drivetemp.sh probe      dump raw smartctl attribute tables for both drives
#   drivetemp.sh ssd        SSD temperature in Celsius, or "--"
#   drivetemp.sh hdd        HDD temperature in Celsius, or "--"
#   drivetemp.sh display    "SSD 44C   HDD 40C" (or "--" per drive if unreadable)
#
# WHY EACH DRIVE NEEDS ITS OWN ATTRIBUTE ID
# -------------------------------------------
# SMART temperature isn't a fixed field -- it's one numbered attribute
# among many, and which number is used for temperature varies by
# vendor/firmware:
#     sda (Samsung SSD 870 EVO 2TB) -> attribute 190, Airflow_Temperature_Cel
#     sdb (WD Elements external)    -> attribute 194, Temperature_Celsius
# Confirmed by running `smartctl -a` on each and grepping for "temp" --
# re-run 'probe' below and update CFG_* if a drive is ever swapped.
#
# WHY THIS NEEDS PASSWORDLESS SUDO
# ----------------------------------
# smartctl needs root (or equivalent) to read most drives' SMART data,
# and conky has no way to type a password interactively. That means a
# NOPASSWD sudoers rule scoped to smartctl specifically -- see the
# install note at the bottom of this file. This is a real trust
# tradeoff: that rule lets ANY process running as this user invoke
# smartctl as root without a prompt, not just this script, and
# smartctl has more than pure read flags (self-tests, attribute
# enable/disable). Scope it as narrowly as you're comfortable with.

set -uo pipefail

# ---------------------------------------------------------------------
# Drive + attribute configuration -- hardcoded, not auto-detected, same
# tradeoff as the interface name in netgraph.lua and the port names in
# headset.sh. Re-run 'probe' after any drive hardware change.
# ---------------------------------------------------------------------
CFG_SSD_DEV="/dev/sda"
CFG_SSD_ATTR=190
CFG_SSD_LABEL="SSD"

CFG_HDD_DEV="/dev/sdb"
CFG_HDD_ATTR=194
CFG_HDD_LABEL="HDD"

# smartctl's own path, resolved once. Sudoers NOPASSWD rules should
# reference this exact path, not a bare "smartctl" -- see install note.
SMARTCTL_BIN=$(command -v smartctl || echo /usr/sbin/smartctl)

# ---------------------------------------------------------------------
probe() {
    echo "== ${CFG_SSD_DEV} (attribute table) =="
    sudo "$SMARTCTL_BIN" -A "$CFG_SSD_DEV" 2>&1 | grep -iE "temp|^ *[0-9]+ "
    echo
    echo "== ${CFG_HDD_DEV} (attribute table) =="
    sudo "$SMARTCTL_BIN" -A "$CFG_HDD_DEV" 2>&1 | grep -iE "temp|^ *[0-9]+ "
}

# read_temp <device> <attribute_id> -- degrees C as a plain integer, or
# "--" if the device is missing, asleep, or the attribute ID is wrong.
read_temp() {
    local dev="$1" attr="$2" out val

    out=$(sudo "$SMARTCTL_BIN" -A "$dev" 2>/dev/null)
    [[ -z $out ]] && { printf -- '--'; return 0; }

    # SMART attribute lines start with "  <ID> <NAME> ...", the actual
    # reading is the last whitespace-separated field ("RAW_VALUE").
    val=$(awk -v id="$attr" '$1==id {print $NF}' <<< "$out")

    if [[ $val =~ ^[0-9]+$ ]]; then
        printf '%s' "$val"
    else
        printf -- '--'
    fi
}

ssd() { read_temp "$CFG_SSD_DEV" "$CFG_SSD_ATTR"; }
hdd() { read_temp "$CFG_HDD_DEV" "$CFG_HDD_ATTR"; }

display() {
    local s h
    s=$(ssd)
    h=$(hdd)
    printf '%s %sC   %s %sC' "$CFG_SSD_LABEL" "$s" "$CFG_HDD_LABEL" "$h"
}

# ---------------------------------------------------------------------
case "${1:-}" in
    probe)    probe ;;
    ssd)      ssd ;;
    hdd)      hdd ;;
    display)  display ;;
    *)
        echo "usage: $(basename "$0") {probe|ssd|hdd|display}" >&2
        exit 2
        ;;
esac

# ---------------------------------------------------------------------
# INSTALL NOTE -- passwordless sudo for smartctl
# ---------------------------------------------------------------------
# Run `command -v smartctl` yourself to confirm the exact binary path
# on this system (commonly /usr/sbin/smartctl), then add a scoped rule
# via a new drop-in file rather than editing /etc/sudoers directly:
#
#     sudo visudo -f /etc/sudoers.d/conky-smartctl
#
# and add this one line (adjust the path if yours differs):
#
#     logansfury ALL=(root) NOPASSWD: /usr/sbin/smartctl
#
# visudo validates syntax before saving, which a plain text editor
# won't -- a broken sudoers file can lock out sudo entirely, so always
# edit it through visudo, never cat/echo directly into the file.
