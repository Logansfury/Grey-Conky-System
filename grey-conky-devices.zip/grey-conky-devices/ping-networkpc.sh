#!/bin/bash
##########################################################################
#                                                                        #
#  This script shows all online/offline hostnames found in a LAN.        #
#  Depends on: arp, dig, fping                                           #
#                                                                        #
#  Made by Koentje  (remon@cobrasoft.nl)                                 #
#                                                          version 1.2   #
##########################################################################
#
# Own hostfile
hostfile="./hosts"
#
# Fontname for hostnames    ex. "Ubuntu Mono:bold:size=15"
fontname1="Droid Sans:size=7"
#
# Fontname for 2nd text line   ex. "Ubuntu Mono:bold:size=10"
fontname2="Droid Sans:size=6"
#
# Vertical spacing between hostnames
voffhost="1"
#
# Horizontal spacing between image and  hostname
hoffhost_left="44"   # Adjusted for the left column
hoffhost_right="-20"   # Adjusted for the right column
#
# Vertical offset for the right column
voffhost_right="-23"  # Adjusted for better alignment
#
# Horizontal spacing between online text and ip address
hoffip="10"
#
# Vertical offset between hostnames in the right column
voffright="1"  # Adjust this value as needed
#
# Color hostname online  (RRGGBB or name like red, white, grey)
colhoston="808080"
#
# Color hostname offline  (RRGGBB or name like red, white, grey)
colhostoff="5e5e5e"
#
# Color "online" text  (RRGGBB or name like red, white, grey)
coltxton="66FF00"
#
# Color "offline" text  (RRGGBB or name like red, white, grey)
coltxtoff="882222"
#
# Color ip address online  (RRGGBB or name like red, white, grey)
colipon="white"
#
# Color ip address offline  (RRGGBB or name like red, white, grey)
colipoff="white"
#
# Exclude these ip addresses  ex. (192.168.1.1 192.168.1.101)
# IP addresses separated by a space!
exclude="192.168.1.101"
#
# Minimum width for the right column
min_width="360"
#
######################################################################################
#########################   EDIT AFTER THIS LINE AT OWN RISK   #######################
######################################################################################

excludes=($exclude)
column=1

while read -r line
do
    # Get hostname or ip address
    ipaddr=$(echo "$line" | awk '{print $1}')
    hostname=$(echo "$line" | awk '{print $2}')
    x=1

    for ips in "${excludes[@]}"
    do
        if [ "$ips" = "$ipaddr" ]; then x=0; continue; fi
    done

    if [ "$x" = "1" ]; then
        # Ping to see if online
        pvar=$(fping -q -c1 -t100 "$ipaddr" >/dev/null 2>&1; echo $?)
        if [ "$pvar" = "0" ]; then
            if [ "$column" -eq 1 ]; then
                echo "\${font $fontname1}\${voffset $voffhost}\${color $colhoston}$hostname\${font}"
                echo "\${font $fontname2}\${color $coltxton}Online\${offset $hoffip}\${color $colipon}$ipaddr"
            else
                echo "\${font $fontname1}\${goto $hoffhost_right}\${voffset $voffhost_right}\${color $colhoston}\${alignr}$hostname\${font}"
                echo "\${font $fontname2}\${goto $hoffhost_right}\${voffset $voffright}\${color $coltxton}\${alignr}Online\${offset $hoffip}\${color $colipon}$ipaddr"
            fi
        else
            if [ "$column" -eq 1 ]; then
                echo "\${font $fontname1}\${voffset $voffhost}\${color $colhostoff}$hostname\${font}"
                echo "\${font $fontname2}\${color $coltxtoff}OFFLINE\${offset $hoffip}\${color $colipoff}$ipaddr"
            else
                echo "\${font $fontname1}\${goto $hoffhost_right}\${voffset $voffhost_right}\${color $colhostoff}\${alignr}$hostname\${font}"
                echo "\${font $fontname2}\${goto $hoffhost_right}\${voffset $voffright}\${color $coltxtoff}\${alignr}OFFLINE\${offset $hoffip}\${color $colipoff}$ipaddr"
            fi
        fi

        if [ "$column" -eq 1 ]; then
            # Switch to the right column after the first six entries
            column=2
        else
            column=1
        fi
    fi

done < "$hostfile"

