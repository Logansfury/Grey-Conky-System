#!/bin/bash
# Directly process the content of /etc/upstream-release/lsb-release with AWK
cat /etc/upstream-release/lsb-release | awk '{ 
    while (length($0) > 28) { 
        print "${alignc}" substr($0, 1, 28); 
        $0 = substr($0, 29); 
    } 
    print "${alignc}" $0; 
}'
